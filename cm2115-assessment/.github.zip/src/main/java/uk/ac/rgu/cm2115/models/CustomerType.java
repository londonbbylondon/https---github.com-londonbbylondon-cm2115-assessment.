package uk.ac.rgu.cm2115.models;

public enum CustomerType {
    INDIVIDUAL,
    BUSINESS,
    CHARITY
}