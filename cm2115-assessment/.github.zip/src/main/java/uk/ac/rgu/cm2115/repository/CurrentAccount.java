package uk.ac.rgu.cm2115.repository;

public interface CurrentAccount {
    void processCardTransaction(Integer amount);
}
